﻿namespace WildFarm.Models.Interfaces;

public interface IMammal : IAnimal
{
    string LivingRegion { get; }
}